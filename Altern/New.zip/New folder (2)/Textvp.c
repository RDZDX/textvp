//240x320 20      (320 / 16)
//240x320 17.78   (320 / 18)
//240x320 14.55   (320 / 22)

//240x240 15      (240 / 16)
//240x240 13.33   (240 / 18)
//240x240 10.91   (240 / 22)

//167x220 13.75   (220 / 16)
//167x220 12.22   (220 / 18)
//167x220 10      (220 / 22)

#include "Textvp.h"

VMWCHAR file_pathw[100] = {0, 0};
VMUINT8 *buffer;
VMFILE f_read;

VMINT filledDsplByLines = 0;
VMINT dynamicPosition = 0;
VMINT fiksedPosition = 0;
VMINT prviousFlPosit = 0;
VMINT endFlPosition = 0;
VMINT tempPosition = 0;
VMINT pageCounter = 1;
VMINT lastPressedKey = 0;
VMBOOL endPressedKey = VM_FALSE;
VMBOOL failoGalasPriesTai = VM_FALSE;
VMINT lapu_kiekis = 0;
VMINT simbl_kiek_pirm_lape = 0;
VMINT x5_puslapiu_adr = 0;
VMBOOL xPressedKey = VM_FALSE; // ???????????????????????????????????????
VMINT x10_procentu_lapu = 0;
VMINT x10_procentu_adr = 0;
VMBOOL trigeris_end = VM_FALSE;
VMBOOL plusPage = VM_FALSE;
VMINT simblKiekEinLape = 0;
VMINT trigeris = 1;
VMBOOL trigeris1 = VM_FALSE;
VMBOOL trigeris2 = VM_FALSE;
VMBOOL trigeris5 = VM_FALSE;
VMBOOL trigeris7 = VM_FALSE;

VMUINT16 color1 = VM_COLOR_WHITE;
VMUINT16 color2 = VM_COLOR_BLACK;
//VMUINT16 color1 = VM_COLOR_BLACK;
//VMUINT16 color2 = VM_COLOR_WHITE;

//int reverse = 320;
int reverse;

int iZZZ; 
int wZZZ;
int hZZZ;

int xy1;
int xy2;

int sWidth;
int sHeight;
int maxLine;
int lineLenghtRestrict;

VMINT fontSize = VM_SMALL_FONT;
//VMINT fontSize = VM_MEDIUM_FONT;
//VMINT fontSize = VM_LARGE_FONT;

VMINT xBaseline;

VMCHAR cZZZ[101] = {0};
VMCHAR qZZZ[101] = "WWW";
VMCHAR zZZZ[101] = "WWp";
VMWCHAR cZZZX[101];
VMWCHAR cZZZY[101];
VMWCHAR cZZZQ[101];

/*****************************************************************************
 * FUNCTION
 *  vm_main
 * DESCRIPTION
 *
 * PARAMETERS
 *
 *
 * RETURNS
 *	none
 *****************************************************************************/

void vm_main(void) {
    layer_hdl[0] = -1;
    vm_reg_sysevt_callback(handle_sysevt);
    vm_reg_keyboard_callback(handle_keyevt);
    vm_font_set_font_size(fontSize);
    //vm_font_set_font_style(FALSE, FALSE, TRUE);
    sWidth = vm_graphic_get_screen_width();
    sHeight = vm_graphic_get_screen_height();
    vm_ascii_to_ucs2(cZZZY, (strlen(qZZZ) + 1) * 2, qZZZ);
    vm_ascii_to_ucs2(cZZZQ, (strlen(zZZZ) + 1) * 2, zZZZ);
    wZZZ = (vm_graphic_get_string_width(cZZZY) / 3);
    hZZZ = vm_graphic_get_string_height(cZZZQ);
    xBaseline = vm_graphic_get_string_baseline(cZZZQ);
    maxLine = sHeight / hZZZ;
    lineLenghtRestrict = (sWidth - 2) - (wZZZ / 3); 
    xy1 = sHeight / hZZZ;
    xy2 = (sHeight - (hZZZ * xy1)) / 2;
    reverse = sHeight;
//  checkFileExist();
    vm_create_timer_ex(5,timer);
}

/*****************************************************************************
 * FUNCTION
 *  handle_sysevt
 * DESCRIPTION
 *  This function handles system events
 * PARAMETERS
 *  event		    	[IN]      message id
 *  param               [IN]      parameter
 * RETURNS
 *	none
 *****************************************************************************/

void handle_sysevt(VMINT message, VMINT param) {

    switch (message) {
        case VM_MSG_CREATE:
            if (param) {vm_wstrcpy(file_pathw, (VMWSTR)param);}
        case VM_MSG_ACTIVE:
            layer_hdl[0] = vm_graphic_create_layer(0, 0, sWidth, sHeight, -1);
            vm_graphic_set_clip(0, 0, sWidth, sHeight);
            buffer = vm_graphic_get_layer_buffer(layer_hdl[0]);
            vm_switch_power_saving_mode(turn_off_mode);
            if (trigeris1 == VM_TRUE) {trigeris2 = VM_TRUE;}
            if (trigeris == 0) {trigeris1 = VM_TRUE;}
            if (trigeris2 == VM_TRUE) {vm_exit_app();}
            break;

        case VM_MSG_PAINT:
            vm_switch_power_saving_mode(turn_off_mode);
            if (trigeris1 == 1) {trigeris2 = 1;}
            if (trigeris == 0) {trigeris1 = 1;}
            if (trigeris2 == 1) {vm_exit_app();}
            else {if (trigeris7 == VM_TRUE) {mre_read_file_display(file_pathw);}}
            break;

        case VM_MSG_INACTIVE:
            vm_switch_power_saving_mode(turn_on_mode);
            if (layer_hdl[0] != -1) vm_graphic_delete_layer(layer_hdl[0]);
            break;

        case VM_MSG_QUIT:
            if (layer_hdl[0] != -1) vm_graphic_delete_layer(layer_hdl[0]);
            break;
    }
}

/*****************************************************************************
 * FUNCTION
 *  handle_keyevt
 * DESCRIPTION
 *
 * PARAMETERS
 *
 *
 * RETURNS
 *	none
 *****************************************************************************/

void handle_keyevt(VMINT event, VMINT keycode) {

    VMCHAR cPageCnter[101] = {0};
    VMWCHAR cPageCnterX[101] = {0, 0};
    VMCHAR cpercentPosition[101] = {0};
    VMWCHAR cpercentPositionX[101] = {0, 0};

    VMCHAR cdynamicPosition[101] = {0};
    VMWCHAR cdynamicPositionX[101];
    VMCHAR cprviousFlPosit[101] = {0};
    VMWCHAR cprviousFlPositX[101];
    VMCHAR cfiksedPosition[101] = {0};
    VMWCHAR cfiksedPositionX[101];

    VMCHAR c1ZZZ[101] = {0};
    VMWCHAR c1ZZZX[101];
    VMCHAR c2ZZZ[101] = {0};
    VMWCHAR c2ZZZX[101];

    VMCHAR c3ZZZ[101] = {0};
    VMWCHAR c3ZZZX[101];
    VMCHAR c4ZZZ[101] = {0};
    VMWCHAR c4ZZZX[101];
    VMCHAR c5ZZZ[101] = {0};
    VMWCHAR c5ZZZX[101];

    int percentData;

    VMBOOL trigerisq = VM_FALSE;     //trigeris nustatymui "fiksedPosition = 0" po uzkrauto puslapio       //bool
    VMBOOL countertriger = VM_FALSE; //trigeris didinti +1 kounteri ar ne                                  //bool

    if (event == VM_KEY_EVENT_UP && keycode == VM_KEY_RIGHT_SOFTKEY) {
        if (layer_hdl[0] != -1) {
            vm_graphic_delete_layer(layer_hdl[0]);
            layer_hdl[0] = -1;
        }
        vm_exit_app();
    }

    if (event == VM_KEY_EVENT_UP && keycode == VM_KEY_LEFT_SOFTKEY) {
        vm_selector_run(0, 0, file);
    }

    if (event == VM_KEY_EVENT_UP && keycode == VM_KEY_DOWN) {

       //Jei ne failo galas pries uzkrovima
       if (fiksedPosition != dynamicPosition) {
          prviousFlPosit = fiksedPosition;
       }

       fiksedPosition = dynamicPosition;

       mre_read_file_display(file_pathw);

       //Jei ne failo galas po uzkrovimo
       if (fiksedPosition != dynamicPosition) {
          countertriger = VM_TRUE;
       }

       //Jei failo galas ir failoGalasPriesTai == 0 && pageCounter != 1 arba dvieju lapu tekstas
       if (fiksedPosition == dynamicPosition && failoGalasPriesTai == VM_FALSE && pageCounter != 1 || fiksedPosition == dynamicPosition && prviousFlPosit == 0 && failoGalasPriesTai == VM_FALSE) {
          countertriger = VM_TRUE;
          failoGalasPriesTai = VM_TRUE;
       }

       if (dynamicPosition > 0 && dynamicPosition == prviousFlPosit && failoGalasPriesTai == VM_FALSE && pageCounter == 1) {
          countertriger = VM_TRUE;
          failoGalasPriesTai = VM_TRUE;
       }

       //Jei antras lapas ir lastPressedKey == 2 ?
       if (dynamicPosition != 0 && dynamicPosition == fiksedPosition && lastPressedKey == 2) {
          countertriger = VM_TRUE;
       }

       if (dynamicPosition == 0 && fiksedPosition == 0 && prviousFlPosit == 0) {
          countertriger = VM_FALSE;
       }

      if (pageCounter == lapu_kiekis) { countertriger = VM_FALSE; }

      //vieno lapo tekstas
      if (countertriger == VM_TRUE) {pageCounter = pageCounter + 1;}

      if (xPressedKey == VM_TRUE) {xPressedKey = VM_FALSE;}

      lastPressedKey = 3;
    }

    if (event == VM_KEY_EVENT_UP && keycode == VM_KEY_UP) {

        if (fiksedPosition == prviousFlPosit && pageCounter != lapu_kiekis && xPressedKey == VM_FALSE || prviousFlPosit == 0 && dynamicPosition != 0 ) {
            dynamicPosition = 0;
            trigerisq = VM_TRUE;
        }
        else{
            dynamicPosition = prviousFlPosit;
        }

        if (pageCounter != 1 && fiksedPosition != dynamicPosition && lastPressedKey != 2) {
           pageCounter = pageCounter - 1;
        }

        mre_read_file_display(file_pathw);

        if (trigerisq == VM_TRUE) {
           fiksedPosition = 0;
           trigerisq = VM_FALSE;
        }

        lastPressedKey = 2;
    }

    if (event == VM_KEY_EVENT_UP && keycode == VM_KEY_NUM1) {

        //percentData = (dynamicPosition * 100) / endFlPosition;
        percentData = (simblKiekEinLape * 100) / endFlPosition;

        if (failoGalasPriesTai == VM_TRUE) { percentData = 100; }
        if (lapu_kiekis < 0) { lapu_kiekis = 1 ; }

        if (endPressedKey == VM_TRUE) {
           endPressedKey = VM_FALSE;
           pageCounter = lapu_kiekis;
        }

        vertical_scrolling_ucs2_text1(file_pathw);

       if (plusPage == VM_TRUE ) {
          sprintf(cPageCnter, "Page # %d of %d", pageCounter + 1, lapu_kiekis + 1);
       } else {
          sprintf(cPageCnter, "Page # %d of %d", pageCounter, lapu_kiekis);
       }

        vm_ascii_to_ucs2(cPageCnterX, (strlen(cPageCnter) + 1) * 2, cPageCnter);
        vertical_scrolling_ucs2_text1(cPageCnterX);

        percentData = (dynamicPosition * 100) / endFlPosition;
        if (failoGalasPriesTai == VM_TRUE) { percentData = 100; }
        if (pageCounter == lapu_kiekis) { percentData = 100; }

        sprintf(cpercentPosition, "Percent: %d", percentData);
        vm_ascii_to_ucs2(cpercentPositionX, (strlen(cpercentPosition) + 1) * 2, cpercentPosition);
        vertical_scrolling_ucs2_text1(cpercentPositionX);

//---------------

        sprintf(cfiksedPosition, "fiksedPosition: %d", fiksedPosition);
        vm_ascii_to_ucs2(cfiksedPositionX, (strlen(cfiksedPosition) + 1) * 2, cfiksedPosition);
        vertical_scrolling_ucs2_text1(cfiksedPositionX);
        sprintf(cdynamicPosition, "dynamicPosition: %d", dynamicPosition);
        vm_ascii_to_ucs2(cdynamicPositionX, (strlen(cdynamicPosition) + 1) * 2, cdynamicPosition);
        vertical_scrolling_ucs2_text1(cdynamicPositionX);
        sprintf(cprviousFlPosit, "prviousFlPosit: %d", prviousFlPosit);
        vm_ascii_to_ucs2(cprviousFlPositX, (strlen(cprviousFlPosit) + 1) * 2, cprviousFlPosit);
        vertical_scrolling_ucs2_text1(cprviousFlPositX);

        sprintf(cZZZ, "Baseline: %d", xBaseline);
        vm_ascii_to_ucs2(cZZZX, (strlen(cZZZ) + 1) * 2, cZZZ);
        vertical_scrolling_ucs2_text1(cZZZX);
        sprintf(c1ZZZ, "Font widht: %d", wZZZ);
        vm_ascii_to_ucs2(c1ZZZX, (strlen(c1ZZZ) + 1) * 2, c1ZZZ);
        vertical_scrolling_ucs2_text1(c1ZZZX);
        sprintf(c2ZZZ, "Font hight: %d", hZZZ);
        vm_ascii_to_ucs2(c2ZZZX, (strlen(c2ZZZ) + 1) * 2, c2ZZZ);
        vertical_scrolling_ucs2_text1(c2ZZZX);
        sprintf(c3ZZZ, "maxLine: %d", maxLine);
        vm_ascii_to_ucs2(c3ZZZX, (strlen(c3ZZZ) + 1) * 2, c3ZZZ);
        vertical_scrolling_ucs2_text1(c3ZZZX);
        sprintf(c4ZZZ, "LineLenght: %d", lineLenghtRestrict);
        vm_ascii_to_ucs2(c4ZZZX, (strlen(c4ZZZ) + 1) * 2, c4ZZZ);
        vertical_scrolling_ucs2_text1(c4ZZZX);
        sprintf(c5ZZZ, "TopMarg: %d", xy2);
        vm_ascii_to_ucs2(c5ZZZX, (strlen(c5ZZZ) + 1) * 2, c5ZZZ);
        vertical_scrolling_ucs2_text1(c5ZZZX);

//--------------

        filledDsplByLines = 0;  
        //reverse = 320;
        reverse = sHeight;
    }

    if (event == VM_KEY_EVENT_UP && keycode == VM_KEY_NUM9) {

       if (endFlPosition > 380) {
       //if (endFlPosition > 1200) {
          dynamicPosition = endFlPosition - 380;
          fiksedPosition = endFlPosition - 380;
          prviousFlPosit = endFlPosition - 380;
       //}
          percentData = 100;
          failoGalasPriesTai = VM_TRUE;
          endPressedKey = VM_TRUE;
          trigeris_end = VM_TRUE;
          mre_read_file_display(file_pathw);
          //endPressedKey = VM_TRUE;
          //trigeris_end = VM_TRUE;
       }

    }

    if (event == VM_KEY_EVENT_UP && keycode == VM_KEY_NUM7) {

        dynamicPosition = 0;
        fiksedPosition = 0;
        prviousFlPosit = 0;
        tempPosition = 0;
        lapu_kiekis = 0;
        failoGalasPriesTai = VM_FALSE;
        lastPressedKey = 0;
        mre_read_file_display(file_pathw);
        pageCounter = 1;
        trigeris_end = VM_FALSE;

    }

    if (event == VM_KEY_EVENT_UP && keycode == VM_KEY_NUM8) {

       x5_puslapiu_adr = dynamicPosition + (simbl_kiek_pirm_lape * 4);

       if (x5_puslapiu_adr < endFlPosition - 380 && endFlPosition > 380 ) {
          dynamicPosition = x5_puslapiu_adr;
          fiksedPosition = x5_puslapiu_adr;
          prviousFlPosit = x5_puslapiu_adr;
          pageCounter = pageCounter + 5;
          mre_read_file_display(file_pathw);
          xPressedKey = VM_TRUE;
       }

       if (x5_puslapiu_adr >= endFlPosition - 380 && trigeris_end == VM_FALSE) {
          dynamicPosition = endFlPosition - 380;
          fiksedPosition = endFlPosition - 380;
          prviousFlPosit = endFlPosition - 380;
          percentData = 100;
          failoGalasPriesTai = VM_TRUE;
          mre_read_file_display(file_pathw);
          endPressedKey = VM_TRUE;
          trigeris_end = VM_TRUE;
          pageCounter = lapu_kiekis;
       }

    }

 if (event == VM_KEY_EVENT_UP && keycode == VM_KEY_NUM6) {

       x10_procentu_lapu = (lapu_kiekis * 9) / 100;
       x10_procentu_adr = dynamicPosition + (simbl_kiek_pirm_lape * x10_procentu_lapu);

       if (x10_procentu_lapu >= 1 && x10_procentu_adr < endFlPosition - 380) {
          dynamicPosition = x10_procentu_adr;
          fiksedPosition = x10_procentu_adr;
          prviousFlPosit = x10_procentu_adr;
          pageCounter = pageCounter + x10_procentu_lapu + 1;
          mre_read_file_display(file_pathw);
          xPressedKey = VM_TRUE;
       }

       if (x10_procentu_adr >= endFlPosition - 380 && trigeris_end == VM_FALSE) {
          dynamicPosition = endFlPosition - 380;
          fiksedPosition = endFlPosition - 380;
          prviousFlPosit = endFlPosition - 380;
          percentData = 100;
          failoGalasPriesTai = VM_TRUE;
          mre_read_file_display(file_pathw);
          endPressedKey = VM_TRUE;
          trigeris_end = VM_TRUE;
       }

    }

    if (event == VM_KEY_EVENT_UP && keycode == VM_KEY_NUM3) {

          if (color1 == VM_COLOR_BLACK) {
             color1 = VM_COLOR_WHITE;
             color2 = VM_COLOR_BLACK;
             dynamicPosition = tempPosition;
             mre_draw_black_rectangle();
             mre_read_file_display(file_pathw);
          } else {
             color1 = VM_COLOR_BLACK;
             color2 = VM_COLOR_WHITE;
             dynamicPosition = tempPosition;
             mre_draw_black_rectangle();
             mre_read_file_display(file_pathw);
          }

    }

    if (event == VM_KEY_EVENT_UP && keycode == VM_KEY_NUM4) {

          if (fontSize == VM_LARGE_FONT) {
             fontSize = VM_SMALL_FONT;
             vm_font_set_font_size(fontSize);
             wZZZ = (vm_graphic_get_string_width(cZZZY) / 3);
             hZZZ = vm_graphic_get_string_height(cZZZQ);
             xBaseline = vm_graphic_get_string_baseline(cZZZQ);
             maxLine = sHeight / hZZZ;
             lineLenghtRestrict = (sWidth - 2) - (wZZZ / 3); 

             xy1 = sHeight / hZZZ;
             xy2 = (sHeight - (hZZZ * xy1)) / 2;

             trigeris = 1;
             trigeris1 = VM_FALSE;
             trigeris2 = VM_FALSE;
             trigeris5 = VM_FALSE;
             trigeris7 = VM_TRUE;
             pageCounter = 1;
             failoGalasPriesTai = VM_FALSE;
             filledDsplByLines = 0;
             //reverse = 320;
             reverse = sHeight;
             dynamicPosition = 0;
             fiksedPosition = 0;
             prviousFlPosit = 0;
             lastPressedKey = 0;
             lapu_kiekis = 0;
             simbl_kiek_pirm_lape = 0;
             x5_puslapiu_adr = 0;
             xPressedKey = VM_FALSE;
             x10_procentu_lapu = 0;
             x10_procentu_adr = 0;
             trigeris_end = VM_FALSE;
             simblKiekEinLape = 0;

             mre_read_file_display(file_pathw);

          } else if (fontSize == VM_MEDIUM_FONT) {
             fontSize = VM_LARGE_FONT;
             vm_font_set_font_size(fontSize);
             wZZZ = (vm_graphic_get_string_width(cZZZY) / 3);
             hZZZ = vm_graphic_get_string_height(cZZZQ);
             xBaseline = vm_graphic_get_string_baseline(cZZZQ);
             maxLine = sHeight / hZZZ;
             lineLenghtRestrict = (sWidth - 2) - (wZZZ / 3); 

             xy1 = sHeight / hZZZ;
             xy2 = (sHeight - (hZZZ * xy1)) / 2;

             trigeris = 1;
             trigeris1 = VM_FALSE;
             trigeris2 = VM_FALSE;
             trigeris5 = VM_FALSE;
             trigeris7 = VM_TRUE;
             pageCounter = 1;
             failoGalasPriesTai = VM_FALSE;
             filledDsplByLines = 0;
             //reverse = 320;
             reverse = sHeight;
             dynamicPosition = 0;
             fiksedPosition = 0;
             prviousFlPosit = 0;
             lastPressedKey = 0;
             lapu_kiekis = 0;
             simbl_kiek_pirm_lape = 0;
             x5_puslapiu_adr = 0;
             xPressedKey = VM_FALSE;
             x10_procentu_lapu = 0;
             x10_procentu_adr = 0;
             trigeris_end = VM_FALSE;
             simblKiekEinLape = 0;

             mre_read_file_display(file_pathw);

          } else {
             fontSize = VM_MEDIUM_FONT;
             vm_font_set_font_size(fontSize);
             wZZZ = (vm_graphic_get_string_width(cZZZY) / 3);
             hZZZ = vm_graphic_get_string_height(cZZZQ);
             xBaseline = vm_graphic_get_string_baseline(cZZZQ);
             maxLine = sHeight / hZZZ;
             lineLenghtRestrict = (sWidth - 2) - (wZZZ / 3); 

             xy1 = sHeight / hZZZ;
             xy2 = (sHeight - (hZZZ * xy1)) / 2;

             trigeris = 1;
             trigeris1 = VM_FALSE;
             trigeris2 = VM_FALSE;
             trigeris5 = VM_FALSE;
             trigeris7 = VM_TRUE;
             pageCounter = 1;
             failoGalasPriesTai = VM_FALSE;
             filledDsplByLines = 0;
             //reverse = 320;
             reverse = sHeight;
             dynamicPosition = 0;
             fiksedPosition = 0;
             prviousFlPosit = 0;
             lastPressedKey = 0;
             lapu_kiekis = 0;
             simbl_kiek_pirm_lape = 0;
             x5_puslapiu_adr = 0;
             xPressedKey = VM_FALSE;
             x10_procentu_lapu = 0;
             x10_procentu_adr = 0;
             trigeris_end = VM_FALSE;
             simblKiekEinLape = 0;

             mre_read_file_display(file_pathw);

          }
    }
 
}

/*****************************************************************************
 * FUNCTION
 *  file
 * DESCRIPTION
 *
 * PARAMETERS
 *
 *
 * RETURNS
 *	none
 *****************************************************************************/

VMINT file(VMWCHAR *FILE_PATH, VMINT wlen) {

    trigeris = 1;
    trigeris1 = VM_FALSE;
    trigeris2 = VM_FALSE;
    trigeris5 = VM_FALSE;
    trigeris7 = VM_TRUE;

    vm_wstrcpy(file_pathw, FILE_PATH);
    pageCounter = 1;
    failoGalasPriesTai = VM_FALSE;
    filledDsplByLines = 0;
    //reverse = 320;
    reverse = sHeight;
    dynamicPosition = 0;
    fiksedPosition = 0;
    prviousFlPosit = 0;
    tempPosition = 0;
    lastPressedKey = 0;
    lapu_kiekis = 0;
    simbl_kiek_pirm_lape = 0;
    x5_puslapiu_adr = 0;
    xPressedKey = VM_FALSE;
    x10_procentu_lapu = 0;
    x10_procentu_adr = 0;
    trigeris_end = VM_FALSE;
    simblKiekEinLape = 0;
    f_read = vm_file_open(file_pathw, MODE_READ, FALSE);
    vm_file_seek(f_read, 0, BASE_END);
    endFlPosition = vm_file_tell(f_read);
    vm_file_close(f_read);

    return 0;
}

VMINT file1(VMWCHAR *FILE_PATH, VMINT wlen) {

    trigeris = 1;
    trigeris1 = VM_FALSE;
    trigeris2 = VM_FALSE;
    trigeris5 = VM_FALSE;
    //trigeris7 = VM_TRUE;

    int lenght;
    lenght = wstrlen(FILE_PATH);

    if (lenght > 0) {
       trigeris7 = VM_TRUE;
       vm_wstrcpy(file_pathw, FILE_PATH);
       pageCounter = 1;
       failoGalasPriesTai = VM_FALSE;
       filledDsplByLines = 0;
       //reverse = 320;
       reverse = sHeight;
       dynamicPosition = 0;
       fiksedPosition = 0;
       prviousFlPosit = 0;
       tempPosition = 0;
       lastPressedKey = 0;
       lapu_kiekis = 0;
       simbl_kiek_pirm_lape = 0;
       x5_puslapiu_adr = 0;
       xPressedKey = VM_FALSE;
       x10_procentu_lapu = 0;
       x10_procentu_adr = 0;
       trigeris_end = VM_FALSE;
       simblKiekEinLape = 0;
       f_read = vm_file_open(file_pathw, MODE_READ, FALSE);
       vm_file_seek(f_read, 0, BASE_END);
       endFlPosition = vm_file_tell(f_read);
       vm_file_close(f_read);
    }
       else {vm_exit_app();
    }

    return 0;
}
/*****************************************************************************
 * FUNCTION
 *  mre_read_file_display
 * DESCRIPTION
 *  This function displays file's cotent on display as 20 text lines
 *  which is actually input textbox
 * PARAMETERS
 *  file name				[IN]      name of file
 * RETURNS
 *	result                  [OUT]     some code for error and success
 *****************************************************************************/
VMINT mre_read_file_display(VMWSTR path) {

    VMUINT nread;

    VMWCHAR sKonv_stringas[MRE_STR_SIZE_MAX + 23] = {0, 0};
    VMCHAR value1[60 + 1] = {0};
    VMCHAR vns_simbl[1 + 1] = {0};
    VMCHAR value10[MRE_STR_SIZE_MAX + 23] = {0}; //uodega max 15 simboliu ilgio? 20 ?
    VMCHAR nauj_strng[60 + 1] = {0};
    VMCHAR konv_stringas[MRE_STR_SIZE_MAX + 23] = {0};      // if ascii mod this string not nessesary
    int myFlPosBackCurr = 0;
    int i, plotis, strng_plot, isve_i_ekr_eil_sk, ilgism;
    char *ptr;
    //VMSTR ptr = NULL;
 
    if(trigeris5 == VM_FALSE) {mre_draw_black_rectangle();}

    f_read = vm_file_open(path, MODE_READ, FALSE);

    vm_file_seek(f_read, dynamicPosition, BASE_CURR);  // Permetame kursoriu i pozicija

    myFlPosBackCurr = dynamicPosition;
    tempPosition = dynamicPosition;

    plotis = 0;
    strng_plot = 0;
    isve_i_ekr_eil_sk = 0;
    plusPage = VM_FALSE;
    ilgism = 0;
    i = 0;


    for (i = 0; i < maxLine; i++) {  // constants: 20 text lines on 320' display (= vm_graphic_get_screen_height[320] / simbolio aukstis [16])
          
        if (ilgism < 61) {
           vm_file_read(f_read, value1, 61, &nread);  // constants: on 240' display on one text line 60 slimest symbols "." or 15 widest symbols "--"
           value1[nread] = '\0';
           //if (vm_file_is_eof(f_read){ galotrigeris = 1; }
           dynamicPosition = vm_file_tell(f_read);  // Issaugome dabartine kursoriaus pozicija faile
           strcat(value10, value1);
           ilgism = strlen(value10);
        }

        //char *ptr = value10;
        ptr = value10;

        while (*ptr != '\0') {

            if (*ptr != '\n') { 
               sprintf(vns_simbl, "%c", *ptr);
               strcat(nauj_strng, vns_simbl);
            }

            ilgism = strlen(nauj_strng);

            if (isve_i_ekr_eil_sk < maxLine && ilgism > 14 || isve_i_ekr_eil_sk < maxLine && *ptr == '\n' || isve_i_ekr_eil_sk < 20 && vm_file_is_eof(f_read)) {
               vm_chset_convert(VM_CHSET_UTF8, VM_CHSET_UCS2, nauj_strng, konv_stringas, (ilgism + 1) * 2);    // change to unicode mod
               //vm_ascii_to_ucs2(sKonv_stringas, (ilgism + 1) * 2, nauj_strng);                                   // change to ascii mod
               vm_wstrcpy(sKonv_stringas, (VMWSTR)konv_stringas);                                              // change to unicode mod
               strng_plot = vm_graphic_get_string_width(sKonv_stringas);
            }

            // 235 = vm_graphic_get_screen_width[=240] - simbolio plotis / 3 + 2[=8/3+2]

            //if (strng_plot > 235 && isve_i_ekr_eil_sk < maxLine || *ptr == '\n' && isve_i_ekr_eil_sk < maxLine) {
            if (strng_plot > lineLenghtRestrict && isve_i_ekr_eil_sk < maxLine || *ptr == '\n' && isve_i_ekr_eil_sk < maxLine) {

                vertical_scrolling_ucs2_text1(sKonv_stringas);
                isve_i_ekr_eil_sk = isve_i_ekr_eil_sk + 1;
                strcpy(nauj_strng, "");
                strng_plot = 0;
            }
            ptr++;
        }

        strcpy(value10, nauj_strng);
        strcpy(nauj_strng, "");
        if (vm_file_is_eof(f_read) || isve_i_ekr_eil_sk == maxLine) {break;}
    }

    dynamicPosition = dynamicPosition - ilgism;
    if (endFlPosition > 0 && dynamicPosition > endFlPosition) {dynamicPosition = endFlPosition;}

    simblKiekEinLape = dynamicPosition;

    if (vm_file_is_eof(f_read)) {
                                               
        if (isve_i_ekr_eil_sk < maxLine && strng_plot != 0 && sKonv_stringas != L'\0') {

            vertical_scrolling_ucs2_text1(sKonv_stringas);
            dynamicPosition = myFlPosBackCurr;
            if (isve_i_ekr_eil_sk == 0 && vm_wstrlen(sKonv_stringas) < 7 && dynamicPosition != 0) {
               plusPage = VM_TRUE;
            }
        }

        if (endFlPosition == dynamicPosition) {dynamicPosition = myFlPosBackCurr;}

        strcpy(value10, "");
    }

    vm_file_close(f_read);

    if (lapu_kiekis == 0) {

       lapu_kiekis = endFlPosition / dynamicPosition;
       if (((float)endFlPosition / dynamicPosition) - lapu_kiekis != 0) {lapu_kiekis = lapu_kiekis + 1;}

    }

    if (simbl_kiek_pirm_lape == 0) {

       simbl_kiek_pirm_lape = dynamicPosition;

    }

    filledDsplByLines = 0;
    //reverse = 320;
    reverse = sHeight;
    trigeris5 = VM_TRUE;
    return 0;
}

/*****************************************************************************
 * FUNCTION
 *  vertical_scrolling_ucs2_text
 * DESCRIPTION
 *
 * PARAMETERS
 *
 * RETURNS
 *
 *****************************************************************************/
//void vertical_scrolling_ucs2_text(VMWSTR ucs2_string) {
void vertical_scrolling_ucs2_text1(VMWSTR ucs2_string) {

    if (filledDsplByLines == 0) {
       mre_draw_black_rectangle();
       filledDsplByLines = xy2;
    }

    vm_graphic_clear_layer_bg(layer_hdl[0]);
    vm_graphic_textout_by_baseline(buffer, 0, filledDsplByLines, ucs2_string, vm_wstrlen(ucs2_string), color2, xBaseline);
    vm_graphic_flush_layer(layer_hdl, 1);
    filledDsplByLines += hZZZ;
}

/*****************************************************************************
 * FUNCTION
 *  checkFileExist
 * DESCRIPTION
 *
 * PARAMETERS
 *
 * RETURNS
 *
 *****************************************************************************/
void checkFileExist(void) {

    VMWCHAR appName[100] = {0, 0};

    create_app_txt_filename(appName, "txt");

    if (vm_wstrlen(file_pathw) == 0) {
       create_auto_full_path_name(file_pathw, appName);
    }

    f_read = vm_file_open(file_pathw, MODE_READ, FALSE);

    if (f_read < 0) {
        vm_file_close(f_read);
        trigeris = vm_selector_run(0, 0, file1);
    } else {
        trigeris7 = VM_TRUE;
        vm_file_seek(f_read, 0, BASE_END);
        endFlPosition = vm_file_tell(f_read);
        vm_file_close(f_read);
        mre_read_file_display(file_pathw);
    }

}

/*****************************************************************************
 * FUNCTION
 *  mre_draw_black_rectangle
 * DESCRIPTION
 *  This function draws rectangle on screen
 * PARAMETERS
 *
 * RETURNS
 *
 *****************************************************************************/
void mre_draw_black_rectangle(void) {

    filledDsplByLines = 0;
    //reverse = 320;
    reverse = sHeight;

    vm_graphic_fill_rect(buffer, 0, 0, sWidth, sHeight, color1, color1);
    vm_graphic_flush_layer(layer_hdl, 1);
}
/*****************************************************************************
 * FUNCTION
 *  create_app_txt_filename
 * DESCRIPTION
 *  
 * PARAMETERS
 *
 * RETURNS
 *
 *****************************************************************************/
void create_app_txt_filename(VMWSTR text, VMSTR extt) {

    VMWCHAR fullPath[100] = {0, 0};
    VMWCHAR appName[100] = {0, 0};
    VMWCHAR wfile_extension[4] = {0, 0};

    vm_get_exec_filename(fullPath);
    vm_get_filename(fullPath, appName);
    vm_ascii_to_ucs2(wfile_extension, 8, extt);
    vm_wstrncpy(text, appName, vm_wstrlen(appName) - 3);
    vm_wstrcat(text, wfile_extension);

}
/*****************************************************************************
 * FUNCTION
 *  create_auto_full_path_name
 * DESCRIPTION
 *  
 * PARAMETERS
 *
 * RETURNS
 *
 *****************************************************************************/
void create_auto_full_path_name(VMWSTR result, VMWSTR fname) {

    VMINT drv;
    VMCHAR fAutoFileName[100] = {0};
    VMWCHAR wAutoFileName[100] = {0, 0};

    if ((drv = vm_get_removable_driver()) < 0) {
       drv = vm_get_system_driver();
    }

    sprintf(fAutoFileName, "%c:\\", drv);
    vm_ascii_to_ucs2(wAutoFileName, (strlen(fAutoFileName) + 1) * 2, fAutoFileName);
    vm_wstrcat(wAutoFileName, fname);
    vm_wstrcpy(result, wAutoFileName);

}

void timer(int a) {
     vm_delete_timer_ex(a);
     checkFileExist();
}

//void vertical_scrolling_ucs2_text1(VMWSTR ucs2_string) {
void vertical_scrolling_ucs2_text(VMWSTR ucs2_string) {

    if (reverse == sHeight) {
       mre_draw_black_rectangle();
       reverse = sHeight - xy2;
    }

    reverse -= hZZZ;

    vm_graphic_clear_layer_bg(layer_hdl[0]); // ????????????????????
    vm_graphic_textout_by_baseline(buffer, 0, reverse, ucs2_string, wstrlen(ucs2_string), color2, xBaseline);
    vm_graphic_flush_layer(layer_hdl, 1);

    //if (reverse <= 0) {reverse = 320;}
    if (reverse <= 0) {reverse = sHeight;}
}

VMINT mre_read_file_display1(VMWSTR path) {

    VMUINT nread;

    VMWCHAR sKonv_stringas[MRE_STR_SIZE_MAX + 23] = {0, 0};
    VMCHAR value1[60 + 1] = {0};
    VMCHAR vns_simbl[1 + 1] = {0};
    VMCHAR value10[MRE_STR_SIZE_MAX + 23] = {0}; //uodega max 15 simboliu ilgio? 20 ?
    VMCHAR nauj_strng[60 + 1] = {0};
    VMCHAR konv_stringas[MRE_STR_SIZE_MAX + 23] = {0};      // if ascii mod this string not nessesary
    int myFlPosBackCurr = 0;
    int i, plotis, strng_plot, isve_i_ekr_eil_sk, ilgism;
    char *ptr;
    //VMSTR ptr = NULL;
 
    if(trigeris5 == VM_FALSE) {mre_draw_black_rectangle();}


    // (if dynamicPosition == 0){} vm_file_seek(f_read, -1, BASE_END);  // Permetame kursoriu i pozicija BASE_END -1 !!!!!


    f_read = vm_file_open(path, MODE_READ, FALSE);

    //if (dynamicPosition == 0) {dynamicPosition = endFlPosition - 1;} 
    if (dynamicPosition == 0) {dynamicPosition = endFlPosition - 62;}  // kas jei gausis minusine reiksme ???

    vm_file_seek(f_read, dynamicPosition, BASE_CURR);
    //vm_file_seek(f_read, 0, BASE_END);  // Permetame kursoriu i pozicija BASE_END
    //vm_file_seek(f_read, -1, BASE_END);  // Permetame kursoriu i pozicija BASE_END -1

    myFlPosBackCurr = dynamicPosition;
   
    plotis = 0;
    strng_plot = 0;
    isve_i_ekr_eil_sk = 0;
    plusPage = VM_FALSE;
    ilgism = 0;
    i = 0;

    for (i = 0; i < maxLine; i++) { // constants: 20 text lines on 320' display (= vm_graphic_get_screen_height[320] / simbolio aukstis [16])
          
        if (ilgism < 61) {
           //permetame kursoriu i gala - 1 
           //vm_file_seek(f_read, -1, BASE_END);
           vm_file_read(f_read, value1, 61, &nread);  // constants: on 240' display on one text line 60 slimest symbols "." or 15 widest symbols "--"
           //permetame kursoriu i (gala - 1) - 61 , ka daryti jei pasiekem pradzia ir ten simboliu liko maziau nei 61 ??
           //vm_file_seek(f_read, xxxxPosition, BASE_CURR);
           value1[nread] = '\0';
           //dynamicPosition = vm_file_tell(f_read);  // Issaugome dabartine kursoriaus pozicija faile
           dynamicPosition = vm_file_tell(f_read) - 120;  // Issaugome dabartine kursoriaus pozicija faile
           strcat(value10, value1);
           ilgism = strlen(value10);
        }

        //char *ptr = value10;
        ptr = value10;

        //for (0 to ilgism) next

        while (*ptr != '\0') {  // mes pabaigoje kaip tik ant nulio !!! while (vm_file_tell(f_read) > 1 )

            if (*ptr != '\n') { 
               sprintf(vns_simbl, "%c", *ptr);
               strcat(nauj_strng, vns_simbl);
            }

            ilgism = strlen(nauj_strng);

            if (isve_i_ekr_eil_sk < 20 && ilgism > 14 || isve_i_ekr_eil_sk < 20 && *ptr == '\n' || isve_i_ekr_eil_sk < 20 && vm_file_is_eof(f_read)) {
               vm_chset_convert(VM_CHSET_UTF8, VM_CHSET_UCS2, nauj_strng, konv_stringas, (ilgism + 1) * 2);    // change to unicode mod
               //vm_ascii_to_ucs2(sKonv_stringas, (ilgism + 1) * 2, nauj_strng);                                   // change to ascii mod
               vm_wstrcpy(sKonv_stringas, (VMWSTR)konv_stringas);                                              // change to unicode mod
               strng_plot = vm_graphic_get_string_width(sKonv_stringas);
            }

            // 235 = vm_graphic_get_screen_width[=240] - simbolio plotis / 3 + 2[=8/3+2]

            if (strng_plot > lineLenghtRestrict && isve_i_ekr_eil_sk < maxLine || *ptr == '\n' && isve_i_ekr_eil_sk < maxLine) {

                if (xBaseline == 0) {xBaseline = vm_graphic_get_string_baseline(sKonv_stringas);}
                vertical_scrolling_ucs2_text1(sKonv_stringas);
                isve_i_ekr_eil_sk = isve_i_ekr_eil_sk + 1;
                strcpy(nauj_strng, "");
                strng_plot = 0;
            }
            ptr++;
        }

        strcpy(value10, nauj_strng);
        strcpy(nauj_strng, "");
        //if (vm_file_is_eof(f_read) || isve_i_ekr_eil_sk == maxLine) {break;}
        if (dynamicPosition <= 0 || isve_i_ekr_eil_sk == maxLine) {break;}
        //if (dynamicPosition < 60 || isve_i_ekr_eil_sk == maxLine) {break;}

    }

    dynamicPosition = dynamicPosition - ilgism;
    if (endFlPosition > 0 && dynamicPosition > endFlPosition) {dynamicPosition = endFlPosition;}

    simblKiekEinLape = dynamicPosition;

    if (vm_file_is_eof(f_read)) {
                                               
        if (isve_i_ekr_eil_sk < maxLine && strng_plot != 0 && sKonv_stringas != L'\0') {

            vertical_scrolling_ucs2_text1(sKonv_stringas);
            dynamicPosition = myFlPosBackCurr;
            if (isve_i_ekr_eil_sk == 0 && vm_wstrlen(sKonv_stringas) < 7 && dynamicPosition != 0) {
               plusPage = VM_TRUE;
            }
        }

        if (endFlPosition == dynamicPosition) {dynamicPosition = myFlPosBackCurr;}

        strcpy(value10, "");
    }

    vm_file_close(f_read);

    if (lapu_kiekis == 0) {

       lapu_kiekis = endFlPosition / dynamicPosition;
       if (((float)endFlPosition / dynamicPosition) - lapu_kiekis != 0) {lapu_kiekis = lapu_kiekis + 1;}

    }

    if (simbl_kiek_pirm_lape == 0) {

       simbl_kiek_pirm_lape = dynamicPosition;

    }

    filledDsplByLines = 0;
    trigeris5 = VM_TRUE;
    reverse = sHeight;
    return 0;
}
